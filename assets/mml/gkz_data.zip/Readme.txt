*************************************************************************
**Evelina Gavrilova, Takuma Kamada and Floris Zoutman********************
*****Is Legal Pot Crippling Mexican Drug Trafficking Organizations?******
*****Economic Journal****************************************************
*************************************************************************



The do file MML_Final replicates all the tables from the text. 

The do file Figure_7_Placebo conveys the placebo routine used to generate Figure 7 in the paper. It also generates the figure itself by using placebo_replications.dta, where we have stored the replications.